from django.apps import AppConfig


class AuditorConfig(AppConfig):
    name = 'auditor'
